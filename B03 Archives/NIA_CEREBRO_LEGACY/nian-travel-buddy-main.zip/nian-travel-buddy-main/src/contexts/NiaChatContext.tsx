import React, { createContext, useContext, useState, useCallback, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useLocation } from "react-router-dom";

// ═══════════════════════════════════════════════════════════════════════════════
// NIA CHAT CONTEXT — CENTRAL ÚNICA DE CONVERSA
// Arquitetura Absoluta: Uma única central de conversa em toda a plataforma.
// Histórico contínuo, único e preservado durante toda a sessão.
// ═══════════════════════════════════════════════════════════════════════════════

// Action types that NIA can trigger
interface NiaClientAction {
  name: string;
  phone?: string | null;
  email?: string | null;
  destination?: string | null;
  notes?: string | null;
  status?: string;
}

export interface NiaMessage {
  id: string;
  role: "user" | "nia";
  content: string;
  timestamp: Date;
  page?: string; // Página onde a mensagem foi enviada
}

interface NiaChatContextType {
  // State
  messages: NiaMessage[];
  isOpen: boolean;
  isProcessing: boolean;
  currentPage: string;
  
  // Actions
  openChat: () => void;
  closeChat: () => void;
  toggleChat: () => void;
  sendMessage: (text: string, onResponse?: (response: string) => void) => Promise<void>;
  clearHistory: () => void;
}

const NiaChatContext = createContext<NiaChatContextType | undefined>(undefined);

// Map routes to context names for the AI
const getContextFromPath = (pathname: string): string => {
  const contextMap: Record<string, string> = {
    '/': 'dashboard',
    '/clientes': 'clientes',
    '/orcamentos': 'orcamentos',
    '/followups': 'followups',
    '/prioridades': 'prioridades',
    '/relatorios': 'relatorios',
    '/viagens': 'viagens',
    '/gargalos': 'gargalos',
    '/treinamento': 'treinamento',
    '/configuracoes': 'configuracoes',
    '/tarefas': 'tarefas',
    '/blindagem': 'blindagem',
    '/decisao': 'decisao',
    '/onboarding': 'onboarding',
  };
  return contextMap[pathname] || 'general';
};

// Map routes to human-readable page names
const getPageNameFromPath = (pathname: string): string => {
  const nameMap: Record<string, string> = {
    '/': 'Dashboard',
    '/clientes': 'Clientes',
    '/orcamentos': 'Orçamentos',
    '/followups': 'Follow-ups',
    '/prioridades': 'Prioridades do Dia',
    '/relatorios': 'Relatórios',
    '/viagens': 'Viagens',
    '/gargalos': 'Detector de Gargalos',
    '/treinamento': 'Treinamento',
    '/configuracoes': 'Banco de Dados da Agência',
    '/tarefas': 'Tarefas',
    '/blindagem': 'Blindagem',
    '/decisao': 'Decisão',
    '/onboarding': 'Onboarding',
    '/conversa': 'Central da N.IA',
  };
  return nameMap[pathname] || 'Navegação';
};

export function NiaChatProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const location = useLocation();
  
  // State
  const [messages, setMessages] = useState<NiaMessage[]>([
    {
      id: "welcome",
      role: "nia",
      content: "Olá! Sou a N.IA, sua sócia estratégica. Pode continuar navegando — estarei aqui para ajudar sempre que precisar.",
      timestamp: new Date(),
      page: "Dashboard",
    },
  ]);
  const [isOpen, setIsOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Current page tracking
  const currentPage = getPageNameFromPath(location.pathname);
  const currentContext = getContextFromPath(location.pathname);
  
  // Ref for message history to use in API calls
  const messagesRef = useRef(messages);
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  const addMessage = useCallback((role: "user" | "nia", content: string, page?: string) => {
    const newMessage: NiaMessage = {
      id: Date.now().toString(),
      role,
      content,
      timestamp: new Date(),
      page,
    };
    setMessages(prev => [...prev, newMessage]);
    return newMessage;
  }, []);

  const openChat = useCallback(() => setIsOpen(true), []);
  const closeChat = useCallback(() => setIsOpen(false), []);
  const toggleChat = useCallback(() => setIsOpen(prev => !prev), []);
  
  const clearHistory = useCallback(() => {
    setMessages([
      {
        id: "welcome-new",
        role: "nia",
        content: "Histórico limpo. Estou pronta para uma nova conversa.",
        timestamp: new Date(),
        page: currentPage,
      },
    ]);
  }, [currentPage]);

  // Parse and execute actions from NIA's response
  const processNiaActions = useCallback(async (message: string): Promise<string> => {
    // Check for CREATE_CLIENT action
    const clientActionMatch = message.match(/\[ACTION:CREATE_CLIENT\]([\s\S]*?)\[\/ACTION:CREATE_CLIENT\]/);
    
    if (clientActionMatch) {
      try {
        const clientData: NiaClientAction = JSON.parse(clientActionMatch[1].trim());
        console.log("[NIA] Detected CREATE_CLIENT action:", clientData);
        
        // TODO: Get actual company_id from auth context
        // For now, using a placeholder - this should be replaced with real auth
        const companyId = "00000000-0000-0000-0000-000000000001";
        
        const { data, error } = await supabase.functions.invoke("nia-create-client", {
          body: {
            action: "upsert",
            client: {
              ...clientData,
              company_id: companyId,
            },
            triggered_by: "nia-chat",
          },
        });
        
        if (error) {
          console.error("[NIA] Error creating client:", error);
          toast({
            title: "Erro ao criar cliente",
            description: "Não foi possível adicionar o cliente. Tente novamente.",
            variant: "destructive",
          });
        } else {
          console.log("[NIA] Client created successfully:", data);
          toast({
            title: "Cliente adicionado",
            description: `${clientData.name} foi adicionado à sua lista.`,
          });
        }
      } catch (parseError) {
        console.error("[NIA] Error parsing client action:", parseError);
      }
      
      // Remove action tags from displayed message
      return message.replace(/\[ACTION:CREATE_CLIENT\][\s\S]*?\[\/ACTION:CREATE_CLIENT\]/, "").trim();
    }
    
    return message;
  }, [toast]);

  const sendMessage = useCallback(async (text: string, onResponse?: (response: string) => void) => {
    if (!text.trim()) return;

    // Add user message immediately with current page context
    addMessage("user", text, currentPage);
    setIsProcessing(true);

    try {
      // Build message history for context (last 20 messages for better context)
      const messageHistory = messagesRef.current.slice(-20).map((msg) => ({
        role: msg.role,
        content: msg.content,
      }));
      
      // Add the new user message to history
      messageHistory.push({ role: "user", content: text });

      const { data, error } = await supabase.functions.invoke("nia-text-chat", {
        body: { 
          messages: messageHistory,
          context: currentContext,
          currentPage: currentPage,
        },
      });

      if (error) {
        throw new Error(error.message);
      }

      if (data?.message) {
        // Process any actions in the response
        const cleanedMessage = await processNiaActions(data.message);
        
        addMessage("nia", cleanedMessage, currentPage);
        
        // Call response callback for TTS
        if (onResponse) {
          onResponse(cleanedMessage);
        }
      }
    } catch (error) {
      console.error("NIA Chat error:", error);
      toast({
        title: "Erro",
        description: "Não foi possível processar sua mensagem. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  }, [addMessage, currentContext, currentPage, toast, processNiaActions]);

  return (
    <NiaChatContext.Provider
      value={{
        messages,
        isOpen,
        isProcessing,
        currentPage,
        openChat,
        closeChat,
        toggleChat,
        sendMessage,
        clearHistory,
      }}
    >
      {children}
    </NiaChatContext.Provider>
  );
}

export function useNiaChat() {
  const context = useContext(NiaChatContext);
  if (context === undefined) {
    throw new Error("useNiaChat must be used within a NiaChatProvider");
  }
  return context;
}
