import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://qrkckvqmafmgmxvjbdcwl.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_qqSSx4L_hsVog-RyymmRKQ_p8NzqScA";

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});
